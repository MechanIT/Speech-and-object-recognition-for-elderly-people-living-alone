console.log("main.js loaded");

// 카메라 초기화
function camInit(stream) {
    var cameraView = document.getElementById("cameraview");
    cameraView.srcObject = stream;
    cameraView.play();
    console.log("카메라 초기화 완료");
}

function camInitFailed(error) {
    console.log("카메라 권한 요청 실패: ", error);
}

// 메인 초기화
function mainInit() {
    console.log("메인 초기화");
    // 미디어 디바이스 지원 여부 확인
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        // Navigator mediaDevices가 지원되지 않음
        alert("미디어 디바이스가 지원되지 않습니다");
        return;
    }

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(camInit)
        .catch(camInitFailed);
}
